package com.example.autoclicker

import android.graphics.Color

const val FAST = 7500L
const val SLOW = 30000L
const val VSLOW = 50000L

/** طريقة اللعب (الاستراتيجية) لكل نوع نبات */
enum class Beh(val color: Int, val title: String, val how: String) {
    SUN(Color.rgb(230, 170, 0), "☀ شمس", "يزرع بالعمود الأول والثاني ويجمع الشمس"),
    SHOOT(Color.rgb(40, 160, 70), "🔫 رماة", "يزرع بالصفوف اللي فيها زومبي (حسب مداه)، ثم رامي ثاني"),
    WALL(Color.rgb(150, 100, 50), "🛡 جدران", "قدام الرماة بالعمود 4-5"),
    COVER(Color.rgb(230, 120, 30), "🎃 غطاء", "فوق الجدار أو الرامي الأمامي بالصف النشط"),
    BOMB(Color.rgb(255, 60, 30), "💣 قنابل", "على أقرب زومبي لما يكونون بصفين أو يقربون"),
    AMBUSH(Color.rgb(120, 60, 180), "🎯 كمائن", "بطريق الزومبي بالصفوف النشطة"),
    TORCH(Color.rgb(255, 140, 0), "🔥 شعلة", "قدام رامي البازلاء مباشرة"),
    UTIL(Color.rgb(60, 140, 200), "🧲 مساعدة", "مرة وحدة (أو مرتين) بمكان آمن"),
    BASE(Color.rgb(30, 160, 160), "🪷 قاعدة", "للمسبح/السطح: يمهد مربعات والنباتات تنزرع فوقه"),
    COFFEE(Color.rgb(110, 70, 40), "☕ قهوة", "يوقظ الفطر النايم تلقائياً")
}

class PlantDef(
    val code: String, val name: String, val cost: Int, val cd: Long, val beh: Beh,
    val c0: Int = 0, val c1: Int = 0, val max: Int = 99,
    val sleepy: Boolean = false, val pea: Boolean = false
) {
    val cols: IntRange get() = c0..c1
}

val CATALOG = listOf(
    // شمس
    PlantDef("SUN", "دوار الشمس", 50, FAST, Beh.SUN, 0, 1),
    PlantDef("TWN", "دوار توأم", 150, VSLOW, Beh.SUN, 0, 1),
    PlantDef("SSH", "فطر الشمس", 25, FAST, Beh.SUN, 0, 1, sleepy = true),
    // رماة
    PlantDef("PEA", "بازلاء", 100, FAST, Beh.SHOOT, 1, 3, pea = true),
    PlantDef("SNP", "بازلاء ثلج", 175, FAST, Beh.SHOOT, 1, 3, pea = true),
    PlantDef("REP", "مكرر", 200, FAST, Beh.SHOOT, 1, 3, pea = true),
    PlantDef("GAT", "غاتلنج", 250, VSLOW, Beh.SHOOT, 1, 3, pea = true),
    PlantDef("SPL", "بازلاء مقسوم", 125, FAST, Beh.SHOOT, 1, 3, pea = true),
    PlantDef("TRI", "ثلاثي", 325, FAST, Beh.SHOOT, 1, 3),
    PlantDef("CAC", "صبار", 125, FAST, Beh.SHOOT, 1, 3),
    PlantDef("STR", "نجمة", 125, FAST, Beh.SHOOT, 1, 3),
    PlantDef("FUM", "فطر الدخان", 75, FAST, Beh.SHOOT, 1, 3, sleepy = true),
    PlantDef("SCA", "فطر الخوّاف", 25, FAST, Beh.SHOOT, 0, 1, sleepy = true),
    PlantDef("PUF", "فطر النفخ", 0, FAST, Beh.SHOOT, 3, 4, sleepy = true),
    PlantDef("SEA", "فطر البحر", 0, FAST, Beh.SHOOT, 3, 4, sleepy = true),
    PlantDef("CAB", "كرنب", 100, FAST, Beh.SHOOT, 0, 2),
    PlantDef("KER", "ذرة", 100, FAST, Beh.SHOOT, 0, 2),
    PlantDef("MEL", "بطيخ", 300, FAST, Beh.SHOOT, 0, 2),
    PlantDef("WML", "بطيخ شتوي", 200, VSLOW, Beh.SHOOT, 0, 2),
    PlantDef("CAT", "ذيل القط", 225, VSLOW, Beh.SHOOT, 0, 2),
    PlantDef("GLO", "فطر الكآبة", 150, VSLOW, Beh.SHOOT, 2, 3, sleepy = true),
    // جدران وغطاء
    PlantDef("WAL", "جوز", 50, SLOW, Beh.WALL, 4, 5),
    PlantDef("TAL", "جوز طويل", 125, SLOW, Beh.WALL, 4, 5),
    PlantDef("GAR", "ثوم", 50, FAST, Beh.WALL, 4, 5),
    PlantDef("PMP", "قرع", 125, SLOW, Beh.COVER),
    // قنابل
    PlantDef("CHR", "كرز", 150, VSLOW, Beh.BOMB),
    PlantDef("JAL", "هالابينو", 125, VSLOW, Beh.BOMB),
    PlantDef("DOM", "فطر الدمار", 125, VSLOW, Beh.BOMB, sleepy = true),
    PlantDef("ICE", "فطر الجليد", 75, VSLOW, Beh.BOMB, sleepy = true),
    // كمائن
    PlantDef("MIN", "لغم بطاطس", 25, SLOW, Beh.AMBUSH, 4, 6),
    PlantDef("SQU", "سكواش", 50, SLOW, Beh.AMBUSH, 4, 6),
    PlantDef("SPK", "سبايك", 100, FAST, Beh.AMBUSH, 4, 7),
    PlantDef("SPR", "سبايك صخري", 125, VSLOW, Beh.AMBUSH, 4, 7),
    PlantDef("CHO", "آكلة", 150, FAST, Beh.AMBUSH, 3, 5),
    PlantDef("HYP", "فطر التنويم", 75, SLOW, Beh.AMBUSH, 4, 6, sleepy = true),
    PlantDef("KLP", "عشب متشابك", 25, FAST, Beh.AMBUSH, 4, 6),
    // شعلة
    PlantDef("TOR", "شعلة", 175, FAST, Beh.TORCH, 2, 5),
    // مساعدة
    PlantDef("MAG", "فطر المغناطيس", 100, FAST, Beh.UTIL, 2, 3, max = 1, sleepy = true),
    PlantDef("GMG", "مغناطيس ذهب", 50, VSLOW, Beh.UTIL, 0, 1, max = 1),
    PlantDef("PLA", "فانوس", 25, VSLOW, Beh.UTIL, 0, 1, max = 1),
    PlantDef("MRG", "القطيفة", 50, FAST, Beh.UTIL, 0, 1, max = 2),
    PlantDef("UMB", "مظلة", 100, FAST, Beh.UTIL, 2, 3, max = 1),
    // قاعدة وقهوة
    PlantDef("LIL", "ورقة نيلوفر", 25, FAST, Beh.BASE, 0, 3),
    PlantDef("FLP", "أصيص", 25, FAST, Beh.BASE, 0, 3),
    PlantDef("COF", "قهوة", 75, FAST, Beh.COFFEE)
)
