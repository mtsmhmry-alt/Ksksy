package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * بوت PvZ:
 * - خريطة مربعات 5×9 بين الدائرتين TL و BR
 * - دائرة $ فوق عداد الشمس: يقرأ الرقم بالـOCR ولا يزرع إلا إذا الشمس تكفي
 * - ▦ يضيف أي نبات من القائمة، ولكل نبات خطته (Beh) وسعره ووقت تبريده
 * - لوحة HUD تعرض الشمس وحالة كل بطاقة (جاهز / تبريد بالثواني / ينقصه شمس)
 */
class ClickService : AccessibilityService() {

    companion object {
        const val ROWS = 5
        const val COLS = 9
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private class Marker(val view: TextView, val lp: WindowManager.LayoutParams)
    private class Card(val def: PlantDef, val m: Marker, var pos: PointF = PointF(), var last: Long = 0L)
    private class Plant(
        val card: Card, var confirmed: Boolean = false, var misses: Int = 0, var age: Int = 0,
        var covered: Boolean = false, var coffeed: Boolean = false
    )

    private lateinit var tlM: Marker
    private lateinit var brM: Marker
    private lateinit var sunM: Marker
    private val cards = mutableListOf<Card>()
    private lateinit var grid: GridView
    private lateinit var hud: TextView
    private lateinit var hudLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panel: View? = null
    private var menu: View? = null
    private lateinit var playBtn: Button
    private var uiReady = false
    private var alive = true

    private var calibrating = true
    private var running = false

    // هندسة الملعب
    private var x0 = 0f
    private var y0 = 0f
    private var cw = 0f
    private var ch = 0f
    private var sunPos = PointF()

    private var baseline: Array<Array<IntArray>>? = null
    private val plants = HashMap<Int, Plant>()
    private val baseCells = HashMap<Int, Int>() // مربع -> عمر (-1 = مؤكد)
    private val rowTtl = IntArray(ROWS)
    private val rowZCol = IntArray(ROWS) { -1 }
    private var sunRotate = 0

    private var sunNow = -1
    private var sunMiss = 0
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        grid = GridView(this)
        wm.addView(grid, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, false))
        tlM = addMarker("TL", Color.rgb(200, 0, 200), 600, 350, 64)
        brM = addMarker("BR", Color.rgb(50, 90, 220), 1900, 950, 64)
        sunM = addMarker("$", Color.rgb(255, 200, 0), 150, 60, 56)
        addCard(CATALOG.first { it.code == "SUN" }, 300, 150)
        addCard(CATALOG.first { it.code == "PEA" }, 362, 150)
        addPanel()
        hud = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(190, 20, 20, 20))
            setPadding(12, 8, 12, 8)
            visibility = View.INVISIBLE
        }
        hudLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false)
            .apply { x = 20; y = 140 }
        wm.addView(hud, hudLp)
        uiReady = true
        grid.postInvalidateDelayed(400)
        hud.postDelayed({ positionHud() }, 400)
        hudTick()
        toast("TL/BR على المربعات، و$ فوق رقم الشمس، ثم ⚙")
    }

    // ---------- واجهة ----------

    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addMarker(label: String, color: Int, x: Int, y: Int, size: Int): Marker {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (size >= 60) 12f else 10f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(190, Color.red(color), Color.green(color), Color.blue(color)))
                setStroke(3, Color.WHITE)
            }
        }
        val lp = overlayParams(size, size, true).apply { this.x = x; this.y = y }
        makeDraggable(tv, lp, tv) { grid.postInvalidate() }
        wm.addView(tv, lp)
        return Marker(tv, lp)
    }

    private fun addCard(def: PlantDef, x: Int, y: Int) {
        cards.add(Card(def, addMarker(def.code, def.beh.color, x, y, 52)))
    }

    private fun addPanel() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(210, 30, 30, 30))
            setPadding(8, 8, 8, 8)
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = TextView(this).apply {
            text = "≡"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(24, 0, 24, 0)
        }
        val calBtn = Button(this).apply { text = "⚙"; setOnClickListener { onCalibClick() } }
        playBtn = Button(this).apply { text = "▶"; setOnClickListener { togglePlay() } }
        val plantBtn = Button(this).apply { text = "▦"; setOnClickListener { toggleMenu() } }
        layout.addView(handle); layout.addView(calBtn); layout.addView(playBtn); layout.addView(plantBtn)

        panelLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply { x = 20; y = 20 }
        makeDraggable(handle, panelLp, layout) { positionHud() }
        wm.addView(layout, panelLp)
        panel = layout
    }

    private fun belowPanelY() = panelLp.y + (panel?.height ?: 120) + 10

    private fun positionHud() {
        if (!uiReady) return
        hudLp.x = panelLp.x
        hudLp.y = belowPanelY()
        try { wm.updateViewLayout(hud, hudLp) } catch (_: Exception) {}
    }

    /** قائمة كل النباتات مجمّعة حسب طريقة اللعب */
    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(Button(this).apply {
            text = "🗑 حذف آخر دائرة"; textSize = 11f
            setOnClickListener { removeLastCard(); closeMenu() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Button(this).apply {
            text = "إغلاق"; textSize = 11f
            setOnClickListener { closeMenu() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(top)
        Beh.values().forEach { beh ->
            val defs = CATALOG.filter { it.beh == beh }
            if (defs.isEmpty()) return@forEach
            col.addView(TextView(this).apply {
                text = beh.title + " — " + beh.how
                textSize = 11f
                setTextColor(Color.rgb(255, 220, 120))
                setPadding(4, 16, 4, 4)
            })
            defs.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEach { d ->
                    row.addView(Button(this).apply {
                        text = "${d.name}\n${d.cost}"
                        textSize = 11f
                        isAllCaps = false
                        setOnClickListener { addCardFromMenu(d); closeMenu() }
                    }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                col.addView(row)
            }
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.argb(240, 25, 25, 25))
            addView(col)
        }
        val dm = resources.displayMetrics
        val lp = overlayParams((dm.widthPixels * 0.45f).toInt(), (dm.heightPixels * 0.7f).toInt(), true)
            .apply { x = panelLp.x; y = belowPanelY() }
        wm.addView(sv, lp)
        menu = sv
    }

    private fun closeMenu() {
        menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        menu = null
    }

    private fun addCardFromMenu(d: PlantDef) {
        if (running) stopBot()
        if (!calibrating) setCalibrating(true)
        val k = cards.size
        addCard(d, 300 + (k % 8) * 62, 220 + (k / 8) * 62)
        toast("${d.name}: ${d.beh.how}. حط الدائرة فوق بطاقته ثم ⚙")
    }

    private fun removeLastCard() {
        if (cards.isEmpty()) return
        if (running) stopBot()
        val c = cards.removeAt(cards.lastIndex)
        try { wm.removeView(c.m.view) } catch (_: Exception) {}
    }

    private fun makeDraggable(
        touchView: View, lp: WindowManager.LayoutParams, windowView: View, onMove: (() -> Unit)?
    ) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        touchView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(windowView, lp)
                    onMove?.invoke()
                }
            }
            true
        }
    }

    /** خريطة المربعات بين TL و BR + مستطيل قراءة الشمس حول $ */
    private inner class GridView(ctx: Context) : View(ctx) {
        private val fillA = Paint().apply { style = Paint.Style.FILL; color = Color.argb(45, 255, 255, 255) }
        private val fillB = Paint().apply { style = Paint.Style.FILL; color = Color.argb(45, 0, 0, 0) }
        private val line = Paint().apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.argb(210, 255, 255, 255)
        }
        private val sunLine = Paint().apply {
            style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.rgb(255, 200, 0)
        }

        override fun onDraw(canvas: Canvas) {
            if (!calibrating || !uiReady) return
            val tx = tlM.lp.x + tlM.lp.width / 2f
            val ty = tlM.lp.y + tlM.lp.height / 2f
            val bx = brM.lp.x + brM.lp.width / 2f
            val by = brM.lp.y + brM.lp.height / 2f
            val w = (bx - tx) / (COLS - 1)
            val h = (by - ty) / (ROWS - 1)
            if (w < 10f || h < 10f) return
            for (r in 0 until ROWS) for (c in 0 until COLS) {
                val l = tx + c * w - w / 2
                val t = ty + r * h - h / 2
                canvas.drawRect(l, t, l + w, t + h, if ((r + c) % 2 == 0) fillA else fillB)
                canvas.drawRect(l, t, l + w, t + h, line)
            }
            val sx = sunM.lp.x + sunM.lp.width / 2f
            val sy = sunM.lp.y + sunM.lp.height / 2f
            canvas.drawRect(sx - w * 0.8f, sy - h * 0.4f, sx + w * 0.8f, sy + h * 0.4f, sunLine)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- HUD ----------

    private fun hudText(): String {
        val now = SystemClock.uptimeMillis()
        val sb = StringBuilder("☀ ").append(if (sunNow >= 0) sunNow.toString() else "؟")
        for (c in cards) {
            val left = c.last + c.def.cd - now
            val st = when {
                left > 0 -> "⏳ ${(left + 999) / 1000}ث"
                sunNow in 0 until c.def.cost -> "💰 ${c.def.cost}"
                else -> "✓ جاهز"
            }
            sb.append("\n").append(c.def.code).append(" ").append(c.def.name).append(": ").append(st)
        }
        return sb.toString()
    }

    private fun hudTick() {
        if (!alive) return
        if (uiReady) hud.text = hudText()
        hud.postDelayed({ hudTick() }, 1000)
    }

    // ---------- المعايرة ----------

    private fun center(m: Marker): PointF {
        val l = IntArray(2)
        m.view.getLocationOnScreen(l)
        return PointF(l[0] + m.view.width / 2f, l[1] + m.view.height / 2f)
    }

    private fun onCalibClick() {
        if (running) stopBot()
        setCalibrating(!calibrating)
    }

    /** يرجع true إذا تغيّرت الحالة فعلاً */
    private fun setCalibrating(on: Boolean): Boolean {
        if (!on) {
            val tl = center(tlM); val br = center(brM)
            val w = (br.x - tl.x) / (COLS - 1)
            val h = (br.y - tl.y) / (ROWS - 1)
            if (w < 20f || h < 20f) {
                toast("TL لازم يكون فوق يسار، و BR تحت يمين")
                return false
            }
            x0 = tl.x; y0 = tl.y; cw = w; ch = h
            cards.forEach { it.pos = center(it.m) }
            sunPos = center(sunM)
        }
        calibrating = on
        val all = listOf(tlM, brM, sunM) + cards.map { it.m }
        for (m in all) {
            m.view.visibility = if (on) View.VISIBLE else View.INVISIBLE
            m.lp.flags = if (on) m.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else m.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(m.view, m.lp)
        }
        grid.visibility = if (on) View.VISIBLE else View.INVISIBLE
        hud.visibility = if (on) View.INVISIBLE else View.VISIBLE
        grid.postInvalidate()
        resetState()
        toast(if (on) "وضع المعايرة" else "تم القفل")
        return true
    }

    private fun resetState() {
        baseline = null
        plants.clear()
        baseCells.clear()
        rowTtl.fill(0)
        sunNow = -1
        sunMiss = 0
        cards.forEach { it.last = 0L }
    }

    // ---------- تشغيل / إيقاف ----------

    private fun togglePlay() {
        if (running) { stopBot(); return }
        if (calibrating && !setCalibrating(false)) return
        if (cards.isEmpty()) { toast("أضف دائرة نبات من ▦ أولاً"); return }
        resetState()
        running = true
        playBtn.text = "⏸"
        toast("يلتقط صورة الملعب الفاضي… لا تلمس الشاشة")
        next(800)
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        playBtn.text = "▶"
    }

    private fun next(delayMs: Long) {
        if (!running) return
        handler.postDelayed({ cycle() }, delayMs)
    }

    // ---------- الحلقة الرئيسية ----------

    private fun cycle() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = result.hardwareBuffer
                val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                val bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, false)
                hwBmp?.recycle()
                hw.close()
                if (bmp != null && running) process(bmp) else next(1500)
            }

            override fun onFailure(errorCode: Int) {
                next(1500)
            }
        })
    }

    private fun cellCenter(r: Int, c: Int) = PointF(x0 + c * cw, y0 + r * ch)

    private fun sample(bmp: Bitmap): Array<Array<IntArray>> =
        Array(ROWS) { r ->
            Array(COLS) { c ->
                val cx = x0 + c * cw
                val cy = y0 + r * ch
                IntArray(25) { k ->
                    val i = k / 5 - 2
                    val j = k % 5 - 2
                    val px = (cx + i * cw * 0.18f).toInt().coerceIn(0, bmp.width - 1)
                    val py = (cy + j * ch * 0.18f).toInt().coerceIn(0, bmp.height - 1)
                    bmp.getPixel(px, py)
                }
            }
        }

    private fun isSun(c: Int) = Color.red(c) > 230 && Color.green(c) > 190 && Color.blue(c) < 110

    private fun frac(cur: Array<Array<IntArray>>, base: Array<Array<IntArray>>, r: Int, c: Int, skipSun: Boolean): Float {
        val a = cur[r][c]; val b = base[r][c]
        var n = 0
        for (k in a.indices) {
            if (skipSun && isSun(a[k])) continue
            val d = abs(Color.red(a[k]) - Color.red(b[k])) +
                abs(Color.green(a[k]) - Color.green(b[k])) +
                abs(Color.blue(a[k]) - Color.blue(b[k]))
            if (d > 90) n++
        }
        return n / a.size.toFloat()
    }

    /** يقرأ رقم الشمس من المستطيل حول $ (OCR). يرجع null إذا فشل */
    private fun readSun(bmp: Bitmap, done: (Int?) -> Unit) {
        try {
            val w = (cw * 1.6f).toInt().coerceAtLeast(40)
            val h = (ch * 0.8f).toInt().coerceAtLeast(30)
            val left = (sunPos.x - w / 2f).toInt().coerceIn(0, bmp.width - 1)
            val top = (sunPos.y - h / 2f).toInt().coerceIn(0, bmp.height - 1)
            val cw2 = minOf(w, bmp.width - left)
            val ch2 = minOf(h, bmp.height - top)
            val crop = Bitmap.createBitmap(bmp, left, top, cw2, ch2)
            val big = Bitmap.createScaledBitmap(crop, cw2 * 2, ch2 * 2, true)
            if (big !== crop) crop.recycle()
            recognizer.process(InputImage.fromBitmap(big, 0))
                .addOnSuccessListener { t ->
                    big.recycle()
                    done(t.text.filter { it.isDigit() }.take(4).toIntOrNull())
                }
                .addOnFailureListener { big.recycle(); done(null) }
        } catch (e: Exception) {
            done(null)
        }
    }

    private fun process(bmp: Bitmap) {
        val cur = sample(bmp)
        if (baseline == null) {
            bmp.recycle()
            baseline = cur
            toast("تمام، البوت شغّال")
            next(1200)
            return
        }
        readSun(bmp) { v -> think(cur, v) }
        bmp.recycle()
    }

    private fun think(cur: Array<Array<IntArray>>, sunRead: Int?) {
        if (!running) return
        if (sunRead != null) { sunNow = sunRead; sunMiss = 0 } else if (++sunMiss >= 3) sunNow = -1
        val base = baseline ?: return

        val occupied = Array(ROWS) { r -> BooleanArray(COLS) { c -> frac(cur, base, r, c, false) > 0.2f } }

        // تحديث حالة النباتات (تأكيد الزرع / اكتشاف المأكول)
        val iter = plants.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            val occ = occupied[e.key / COLS][e.key % COLS]
            val p = e.value
            if (p.confirmed) {
                if (occ) p.misses = 0 else if (++p.misses >= 2) iter.remove()
            } else {
                if (occ) p.confirmed = true
                else if (++p.age >= 3) { p.card.last = 0L; iter.remove() }
            }
        }
        val bi = baseCells.entries.iterator()
        while (bi.hasNext()) {
            val e = bi.next()
            if (e.value >= 0) {
                if (occupied[e.key / COLS][e.key % COLS]) e.setValue(-1)
                else if (e.value + 1 >= 3) bi.remove() else e.setValue(e.value + 1)
            }
        }

        // مكان أقرب زومبي في كل صف (آخر 5 أعمدة، بدون مربعات نباتاتنا)
        for (r in 0 until ROWS) {
            val z = (COLS - 5 until COLS).firstOrNull { c ->
                val k = r * COLS + c
                !plants.containsKey(k) && !baseCells.containsKey(k) && frac(cur, base, r, c, true) > 0.06f
            }
            if (z != null) { rowTtl[r] = 6; rowZCol[r] = z } else if (rowTtl[r] > 0) rowTtl[r]--
        }
        val active = BooleanArray(ROWS) { rowTtl[it] > 0 }

        val taps = mutableListOf<PointF>()

        // شمس في مربعات فاضية
        var sunTaps = 0
        loop@ for (r in 0 until ROWS) for (c in 0 until COLS) {
            if (occupied[r][c] || plants.containsKey(r * COLS + c)) continue
            if (cur[r][c].count { isSun(it) } >= 5) {
                taps.add(cellCenter(r, c))
                if (++sunTaps >= 3) break@loop
            }
        }

        // شمس تطلع من منتجات الشمس: اضغط عليها بالتناوب
        val producers = plants.entries.filter { it.value.card.def.beh == Beh.SUN && it.value.confirmed }
            .map { it.key }.sorted()
        if (producers.isNotEmpty()) {
            repeat(minOf(2, producers.size)) {
                val k = producers[sunRotate % producers.size]
                sunRotate++
                taps.add(cellCenter(k / COLS, k % COLS))
            }
        }

        // قرار الزرع (نبتة وحدة في كل دورة)
        decidePlant(occupied, active)?.let { (card, r, c) ->
            val k = r * COLS + c
            card.last = SystemClock.uptimeMillis()
            taps.add(card.pos)
            taps.add(cellCenter(r, c))
            if (sunNow >= 0) sunNow -= card.def.cost
            when (card.def.beh) {
                Beh.BOMB -> {}
                Beh.BASE -> baseCells[k] = 0
                Beh.COVER -> plants[k]?.covered = true
                Beh.COFFEE -> plants[k]?.coffeed = true
                else -> plants[k] = Plant(card)
            }
            Unit
        }

        runTaps(taps)
        next(taps.size * 320L + 1100L)
    }

    /** بطاقة جاهزة (انتهى تبريدها، والشمس تكفي، ولم تتجاوز الحد الأقصى) */
    private fun ready(beh: Beh): Card? {
        val now = SystemClock.uptimeMillis()
        return cards.filter { c ->
            c.def.beh == beh && now - c.last >= c.def.cd &&
                (sunNow < 0 || sunNow >= c.def.cost) &&
                plants.values.count { it.card === c } < c.def.max
        }.minByOrNull { it.last }
    }

    private fun plan(beh: Beh, rows: List<Int>, free: (Int, Int) -> Boolean): Triple<Card, Int, Int>? {
        val card = ready(beh) ?: return null
        for (r in rows) for (c in card.def.cols) if (free(r, c)) return Triple(card, r, c)
        return null
    }

    private fun decidePlant(occupied: Array<BooleanArray>, active: BooleanArray): Triple<Card, Int, Int>? {
        val free = { r: Int, c: Int ->
            val k = r * COLS + c
            !plants.containsKey(k) && (!occupied[r][c] || baseCells.containsKey(k))
        }
        val freeBase = { r: Int, c: Int ->
            val k = r * COLS + c
            !occupied[r][c] && !plants.containsKey(k) && !baseCells.containsKey(k)
        }
        fun count(beh: Beh, row: Int = -1) =
            plants.entries.count { it.value.card.def.beh == beh && (row < 0 || it.key / COLS == row) }
        val order = listOf(2, 1, 3, 0, 4)
        val act = order.filter { active[it] }

        // 0) قواعد المسبح/السطح
        if (baseCells.size < 12) plan(Beh.BASE, order, freeBase)?.let { return it }

        // 1) أساس الشمس
        if (count(Beh.SUN) < 2) plan(Beh.SUN, order, free)?.let { return it }

        // 2) رامي في كل صف فيه زومبي
        plan(Beh.SHOOT, act.filter { count(Beh.SHOOT, it) < 1 }, free)?.let { return it }

        // 3) قنبلة: زومبي بصفين أو أكثر، أو قرّب. تنزل على أقرب زومبي
        if (act.size >= 2 || act.any { rowZCol[it] in 0..5 }) {
            ready(Beh.BOMB)?.let { card ->
                val r = act.minByOrNull { rowZCol[it] }
                if (r != null) return Triple(card, r, rowZCol[r].coerceIn(0, COLS - 1))
            }
        }

        // 4) شعلة قدام رامي البازلاء
        ready(Beh.TORCH)?.let { torch ->
            for (r in act) {
                if (count(Beh.TORCH, r) >= 1) continue
                val sc = plants.entries
                    .filter { it.key / COLS == r && it.value.confirmed && it.value.card.def.pea }
                    .map { it.key % COLS }.minOrNull() ?: continue
                if (sc + 1 < COLS && free(r, sc + 1)) return Triple(torch, r, sc + 1)
            }
        }

        // 5) كمين بطريق الزومبي
        plan(Beh.AMBUSH, act.filter { count(Beh.AMBUSH, it) < 1 }, free)?.let { return it }

        // 6) جدار قدام الرامي
        plan(Beh.WALL, act.filter { count(Beh.SHOOT, it) >= 1 && count(Beh.WALL, it) < 1 }, free)?.let { return it }

        // 7) غطاء (قرع) فوق الأمامي في صف نشط
        ready(Beh.COVER)?.let { card ->
            val e = plants.entries.filter {
                val b = it.value.card.def.beh
                it.value.confirmed && !it.value.covered && (b == Beh.WALL || b == Beh.SHOOT) && active[it.key / COLS]
            }.maxByOrNull { it.key % COLS }
            if (e != null) return Triple(card, e.key / COLS, e.key % COLS)
        }

        // 8) قهوة لإيقاظ الفطر
        ready(Beh.COFFEE)?.let { card ->
            val e = plants.entries.firstOrNull { it.value.confirmed && it.value.card.def.sleepy && !it.value.coffeed }
            if (e != null) return Triple(card, e.key / COLS, e.key % COLS)
        }

        // 9) نباتات المساعدة (مرة وحدة)
        plan(Beh.UTIL, order, free)?.let { return it }

        // 10) مزيد من الشمس
        if (count(Beh.SUN) < 6) plan(Beh.SUN, order, free)?.let { return it }

        // 11) رماة احتياط بكل الصفوف، ثم رامي ثاني بالصفوف النشطة
        plan(Beh.SHOOT, order.filter { count(Beh.SHOOT, it) < 1 }, free)?.let { return it }
        plan(Beh.SHOOT, act.filter { count(Beh.SHOOT, it) < 2 }, free)?.let { return it }
        return null
    }

    // ---------- النقر ----------

    private fun runTaps(points: List<PointF>) {
        points.forEachIndexed { i, p ->
            handler.postDelayed({ if (running) tap(p.x, p.y) }, i * 320L)
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 30)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }

    override fun onDestroy() {
        alive = false
        stopBot()
        closeMenu()
        try { wm.removeView(grid) } catch (_: Exception) {}
        try { wm.removeView(hud) } catch (_: Exception) {}
        (listOf(tlM, brM, sunM) + cards.map { it.m }).forEach { try { wm.removeView(it.view) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
