package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "PvZ Bot\n\n" +
                "1) فعّل خدمة PvZ Bot من إعدادات إمكانية الوصول\n" +
                "2) افتح اللعبة وادخل مرحلة\n" +
                "3) اضغط ⚙: حرّك TL فوق أول مربع و BR فوق آخر مربع لين الخريطة تنطبق على الملعب\n" +
                "4) حرّك دائرة \$ لين المستطيل الأصفر يغطي رقم الشمس\n" +
                "5) زر ▦: اختر أي نبات (فيه كل النباتات)، وحط دائرته فوق بطاقته. كل نبات له خطته وسعره ووقت تبريده\n" +
                "6) اسحب اللوحة (≡) خارج الملعب، ثم ⚙ للقفل. تحتها يظهر عداد الشمس وحالة كل بطاقة\n" +
                "7) اضغط ▶ والملعب فاضي قبل ما تنزل أي نبات أو يجي زومبي"
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
